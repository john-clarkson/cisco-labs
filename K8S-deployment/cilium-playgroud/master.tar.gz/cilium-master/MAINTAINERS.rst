Cilium Maintainers
==================

 * `André Martins`_ (Isovalent)
 * `Joe Stringer`_ (Isovalent)

Hubble Maintainers
==================

 * `Glib Smaga`_ (Isovalent)
 * `Sebastian Wicki`_ (Isovalent)

Cilium & Hubble Core Team
=========================

 * `Chris Tarazi`_ (Isovalent)
 * `Daniel Borkmann`_ (Isovalent)
 * `Deepesh Pathak`_
 * `Eloy Coto`_ (Red Hat)
 * `Ian Vernon`_
 * `Ilya Dmitrichenko`_ (Isovalent)
 * `Jarno Rajahalme`_ (Isovalent)
 * `John Fastabend`_ (Isovalent)
 * `Laurent Bernaille`_ (Datadog)
 * `Maciej Kwiek`_ (Isovalent)
 * `Martynas Pumputis`_ (Isovalent)
 * `Michael Rostecki`_ (SUSE)
 * `Michi Mutsuzaki`_ (Isovalent)
 * `Nirmoy Das`_ (AMD)
 * `Paul Chaignon`_ (Isovalent)
 * `Quentin Monnet`_ (Isovalent)
 * `Ray Bejjani`_
 * `Robin Hahling`_ (Isovalent)
 * `Thomas Graf`_ (Isovalent)
 * `Tobias Klauser`_ (Isovalent)
 * `Vlad Ungureanu`_ (Palantir)
 * `Weilong Cui`_ (Google)
 * `Yongkun Gui`_ (Google)
 * `Zang Li`_ (Google)

Please see the AUTHORS file for the full list of contributors to the Cilium
project.

.. _`André Martins`: https://github.com/aanm
.. _`Chris Tarazi`: https://github.com/christarazi
.. _`Daniel Borkmann`: https://github.com/borkmann
.. _`Deepesh Pathak`: https://github.com/fristonio
.. _`Eloy Coto`: https://github.com/eloycoto
.. _`Glib Smaga`: https://github.com/glibsm
.. _`Ian Vernon`: https://github.com/ianvernon
.. _`Ilya Dmitrichenko`: https://github.com/errordeveloper
.. _`Jarno Rajahalme`: https://github.com/jrajahalme
.. _`Joe Stringer`: https://github.com/joestringer
.. _`John Fastabend`: https://github.com/jrfastab
.. _`Laurent Bernaille`: https://github.com/lbernail
.. _`Maciej Kwiek`: https://github.com/nebril
.. _`Martynas Pumputis`: https://github.com/brb
.. _`Michael Rostecki`: https://github.com/mrostecki
.. _`Michi Mutsuzaki`: https://github.com/michi-covalent
.. _`Nirmoy Das`: https://github.com/nirmoy
.. _`Paul Chaignon`: https://github.com/pchaigno
.. _`Quentin Monnet`: https://github.com/qmonnet
.. _`Ray Bejjani`: https://github.com/raybejjani
.. _`Robin Hahling`: https://github.com/Rolinh
.. _`Sebastian Wicki`: https://github.com/gandro
.. _`Thomas Graf`: https://github.com/tgraf
.. _`Tobias Klauser`: https://github.com/tklauser
.. _`Vlad Ungureanu`: https://github.com/ungureanuvladvictor
.. _`Weilong Cui`: https://github.com/Weil0ng
.. _`Yongkun Gui`: https://github.com/anfernee
.. _`Zang Li`: https://github.com/lzang
