Create a node group
===================

.. code:: bash

    eksctl create nodegroup --cluster test-cluster --nodes 2
