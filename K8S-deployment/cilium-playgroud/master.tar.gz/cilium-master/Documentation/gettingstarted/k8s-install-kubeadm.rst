.. only:: not (epub or latex or html)

    WARNING: You are looking at unreleased Cilium documentation.
    Please use the official rendered version released here:
    https://docs.cilium.io

Installation using kubeadm
==========================

Instructions about installing Cilium on Kubernetes cluster deployed by kubeadm
are available in the `official Kubernetes documentation <https://kubernetes.io/docs/setup/production-environment/tools/kubeadm/create-cluster-kubeadm/#pod-network>`_.
