
.. code:: bash

    az aks get-credentials --name $CLUSTER_NAME --resource-group $RESOURCE_GROUP_NAME
