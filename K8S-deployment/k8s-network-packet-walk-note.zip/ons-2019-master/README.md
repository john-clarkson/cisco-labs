Open Networking Summit, North America - 2019

https://onsna19.sched.com/event/LKTH/packet-walks-in-kuberenetes-don-jayakody-big-switch

Don Jayakody, Big Switch

Feel free to reach out:
Twitter: @techjaya
Linkedin: linkedin.com/in/jayakody

