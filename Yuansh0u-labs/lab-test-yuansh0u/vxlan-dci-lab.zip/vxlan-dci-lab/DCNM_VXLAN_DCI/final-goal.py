###Credencials

admin
Cciedc@hit1er
###SN
9581OW4YE5Q =spine-1 150.1.93.100
90BCXIO7L4X =leaf-1 150.1.93.101
9B3JPMW85MC =leaf-2 150.1.93.102

98314V8H44P =spine-3 150.1.93.33
98QE5QXB76A =leaf-3 150.1.93.103
###server info
server1 vlan10 tag= 172.17.10.1->254
server2 vlan10 tag= 172.17.10.2->254
172.17.10.254=anycast gateway<leaf1/2>
###VNI info
vlan10->l2vni=30000
vlan1234->l3vni=50000

9TZUCZ1J7KJ=spine=bgw
