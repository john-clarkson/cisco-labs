Abort Auto Provisioning and continue with normal setup ?(yes/no)[n]: yes
Disabling POAP

        ---- System Admin Account Setup ----


Do you want to enforce secure password standard (yes/no) [y]: no

 Enter the password for "admin": admin
  Confirm the password for "admin": admin

  Would you like to enter the basic configuration dialog (yes/no): no
